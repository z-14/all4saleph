 <?include("sessions.php");
 $_SESSION["user_photo"] = "yes";
 
 ?>
 
 <?
include("sessions.php");
include("globalconfig.php");
include("sql.php");
$_SESSION["user_photo"] = $_GET["user_photo"];
?>
<!-- Search section -->
	<div class="search-form-section">
	
	
	
		<div class="sf-warp">
			<div class="container">
			
				<div class="big-search-form">


<form enctype="multipart/form-data" method="post" name="uploadphoto" >
  <input type="file" id="file" name="upload[]" onclick="showMe();"  required />
  <button class="bsf-btn"><label for="file" onclick="showMe();">Get a file</label></button>
  <button id="uploadbutton" class="bsf-btn" onclick="uploadIt('uploadphoto','merchant_apply_file_upload.php','merchant_apply.php'), hideMe(this.id)">go</button>
</form>


				</div>
			</div>
		</div>
	</div>
	<!-- Search section end -->
	
 <?

 exit
 ?>
 onChange="uploadIt('uploadphoto','merchant_apply_file_upload.php')"
 
 <iframe src="merchant_apply_file_upload.php" height="100%" width="100%" scroll="none" frameBorder="0"></iframe> 